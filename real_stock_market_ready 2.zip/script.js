const products=[
{id:1,name:"سماعة لاسلكية",price:35000,icon:"🎧"},
{id:2,name:"ساعة ذكية",price:55000,icon:"⌚"},
{id:3,name:"شاحن سريع",price:18000,icon:"🔌"},
{id:4,name:"حافظة هاتف",price:12000,icon:"📱"},
{id:5,name:"لوحة مفاتيح",price:42000,icon:"⌨️"},
{id:6,name:"ماوس لاسلكي",price:25000,icon:"🖱️"}
];
let cart=JSON.parse(localStorage.getItem("rsm_cart")||"[]");
const grid=document.getElementById("grid"),count=document.getElementById("count"),drawer=document.getElementById("drawer"),shade=document.getElementById("shade"),items=document.getElementById("cartItems"),total=document.getElementById("total");
function money(n){return n.toLocaleString("ar-IQ")+" د.ع"}
function save(){localStorage.setItem("rsm_cart",JSON.stringify(cart));renderCart()}
function renderProducts(){grid.innerHTML=products.map(p=>`<article class="product"><div class="pic">${p.icon}</div><h3>${p.name}</h3><p class="price">${money(p.price)}</p><button class="btn" onclick="add(${p.id})">أضف للسلة</button></article>`).join("")}
function add(id){const p=products.find(x=>x.id===id),x=cart.find(x=>x.id===id);x?x.qty++:cart.push({...p,qty:1});save();openCart()}
function remove(id){cart=cart.filter(x=>x.id!==id);save()}
function renderCart(){count.textContent=cart.reduce((a,x)=>a+x.qty,0);items.innerHTML=cart.length?cart.map(x=>`<div class="cartLine"><span>${x.name}<small> × ${x.qty}</small></span><b>${money(x.price*x.qty)}</b><button onclick="remove(${x.id})">حذف</button></div>`).join(""):"<p>السلة فارغة.</p>";total.textContent=money(cart.reduce((a,x)=>a+x.price*x.qty,0))}
function openCart(){drawer.classList.add("open");shade.classList.add("show")}
function closeCart(){drawer.classList.remove("open");shade.classList.remove("show")}
document.getElementById("cartBtn").onclick=openCart;document.getElementById("close").onclick=closeCart;shade.onclick=closeCart;
renderProducts();renderCart();